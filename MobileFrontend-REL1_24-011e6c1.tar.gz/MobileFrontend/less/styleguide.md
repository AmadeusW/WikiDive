<div class="content">
	<h2>Overview</h2>

	This document describes the UI patterns for mobile.

	<h2>See Also</h2>
	<ul>
		<li>
			<a href="../js/index.html">Documentation for JavaScript</a>
		</li>
	</ul>
</div>
