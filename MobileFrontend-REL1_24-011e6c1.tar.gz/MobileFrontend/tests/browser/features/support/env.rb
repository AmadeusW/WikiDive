require "rubygems"
require "bundler/setup"

Bundler.require
