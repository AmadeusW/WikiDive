class MainPage
  include PageObject
  include URL

  page_url URL.url("Main_Page")
end
