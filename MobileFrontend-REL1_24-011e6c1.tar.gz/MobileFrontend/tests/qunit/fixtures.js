// turn sinon into a global
window.sinon = sinon;
